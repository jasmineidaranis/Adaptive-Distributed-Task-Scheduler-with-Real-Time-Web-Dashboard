package com.scheduler.model;

public enum TaskStatus {
    PENDING, RUNNING, COMPLETED, FAILED, CANCELLED
}